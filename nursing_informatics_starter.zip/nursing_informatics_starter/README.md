# Nursing Informatics Projects

This repository contains my personal work, notes, and experiments as part of my master's program in Nursing Informatics.

## Areas of Focus
- Electronic Health Record (EHR) data cleaning
- Patient safety dashboards
- HL7/FHIR research
- Python scripts for clinical data
- Literature review summaries
